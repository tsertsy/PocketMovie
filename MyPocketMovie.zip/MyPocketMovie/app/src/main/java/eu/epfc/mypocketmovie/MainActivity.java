package eu.epfc.mypocketmovie;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import eu.epfc.mypocketmovie.model.HttpRequestService;
import eu.epfc.mypocketmovie.model.Movie;
import eu.epfc.mypocketmovie.model.MovieManager;

public class MainActivity extends AppCompatActivity {
    private RecyclerView moviesRecyclerView;
    private List<Movie> movies;
    private static String TAG = "MainActivity";
//    private static String TMDB_URL="https://api.themoviedb.org/3/discover/movie?api_key=ea2dcee690e0af8bb04f37aa35b75075";
    private static String TMDB_URL="https://api.themoviedb.org/3/movie/popular?page=1&api_key=ea2dcee690e0af8bb04f37aa35b75075";
    private HttpRequestService httpRequestService = new HttpRequestService();
    private RecentMoviesAdapter moviesAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        onCreatePopulateFromInternet();
    }
    private void loadMovieData(String urlString)
    {
        String jsonString = loadJSONFromUrl(urlString);
        if (jsonString != null)
        {
            populateMovieModelsFromJSONString(jsonString);
        }
    }

    private String loadJSONFromUrl(String urlString) {
        String json = null;
        // create a Broadcast receiver
        HttpReceiver httpReceiver = new HttpReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("httpRequestComplete");
        // register the broadcast receiver to intent with action "httpRequestComplete"
        registerReceiver(httpReceiver,intentFilter);


        HttpRequestService.startActionRequestHttp(getApplicationContext(), urlString);

        RecyclerView recyclerView = findViewById(R.id.list_recent_movies);

        // set the adapter of the RecyclerView
        moviesAdapter = new RecentMoviesAdapter();
        recyclerView.setAdapter(moviesAdapter);

        // set the layoutManager of the recyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        return json;

    }

    /**
     * This method create Planet objects from a json String and store them in the field List<Planet> planets
     * @param jsonString the json String containing planet informations
     */
    private void populateMovieModelsFromJSONString(String jsonString)
    {
        movies.clear();

        try {

            // get the root json element
            JSONObject jsonObject = new JSONObject(jsonString);

            // get the "results" array from the root JSON element
            JSONArray jsonMovies = jsonObject.getJSONArray("results");

            // for all the planets listed in results
            for (int i = 0; i<jsonMovies.length(); ++i)
            {
                // get the JSON corresponding to the planet
                JSONObject jsonMovie = jsonMovies.getJSONObject(i);

                String title = jsonMovie.getString("title");
                double rating = extractDoubleValueFromJsonMovie(jsonMovie,"popularity");
                String overview = jsonMovie.getString("overview");
                String imagepath = jsonMovie.getString("poster_path");


                // create a new movie object
                Movie newMovie = new Movie(title,overview, rating, imagepath);

                // store it in our planets List field
                this.movies.add(newMovie);
            }

        } catch (JSONException e) {
            Log.e(TAG,"can't parse json string correctly");
            e.printStackTrace();
        }
    }

    private long extractLongValueFromJsonMovie(JSONObject jsonMovie, String name)
    {
        try {
            return jsonMovie.getLong(name);
        }

        catch(JSONException e)
        {
            return 0;
        }
    }
    private double extractDoubleValueFromJsonMovie(JSONObject jsonMovie, String name)
    {
        try {
            return jsonMovie.getDouble(name);
        }

        catch(JSONException e)
        {
            String s = e.getMessage();
            Log.d("MainActivity", e.getMessage());
            return 0;
        }
    }
    private List<Movie> parseTopMoviesResponse(String jsonString)
    {
        ArrayList<Movie> movies = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(jsonString);
            JSONArray jsonArticles = jsonObject.getJSONArray("results");

            for (int i = 0; i<jsonArticles.length(); ++i)
            {
                JSONObject jsonMovie = jsonArticles.getJSONObject(i);

                String title = jsonMovie.getString("title");
                String overview = jsonMovie.getString("overview");
                double rating =extractDoubleValueFromJsonMovie(jsonMovie,"popularity");
                String imagepath = jsonMovie.getString("poster_path");

                Movie newMovie = new Movie(title,overview, rating, imagepath);

                movies.add(newMovie);
            }

        } catch (JSONException e) {
            Log.e(TAG,"can't parse json string correctly");
            e.printStackTrace();
        }

        return movies;

    }

    private class HttpReceiver extends BroadcastReceiver
    {
        @Override
        public void onReceive(Context context, Intent intent) {

            // extract JSON response from the intent
            String response = intent.getStringExtra("responseString");

            // parse Articles from JSON
            List<Movie> movies = parseTopMoviesResponse(response);

            // update the recycler view with those new articles
            moviesAdapter.setMovieData(movies);
        }
    }




    protected void onCreatePopulateFromInternet(){
        setContentView(R.layout.activity_main);

        HttpReceiver httpReceiver = new HttpReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("httpRequestComplete");
        intentFilter.addAction("httpRequestFailed");
        registerReceiver(httpReceiver,intentFilter);
        String urlString = "https://api.themoviedb.org/3/movie/popular?page=1&api_key=ea2dcee690e0af8bb04f37aa35b75075";
        //String urlString = "https://api.themoviedb.org/3/discover/movie?api_key=ea2dcee690e0af8bb04f37aa35b75075";
        HttpRequestService.startActionRequestHttp(getApplicationContext(), urlString);

        RecyclerView recyclerView = findViewById(R.id.list_recent_movies);

        // set the adapter of the RecyclerView
        moviesAdapter = new RecentMoviesAdapter();
        recyclerView.setAdapter(moviesAdapter);

        // set the layoutManager of the recyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        MovieManager.getInstance().initWithContext(getApplicationContext());
    }

}
