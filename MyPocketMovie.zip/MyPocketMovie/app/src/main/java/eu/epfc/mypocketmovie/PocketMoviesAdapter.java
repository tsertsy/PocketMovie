package eu.epfc.mypocketmovie;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import eu.epfc.mypocketmovie.model.Movie;

/**
 * Created by Olivier on 12/05/2018.
 */

public class PocketMoviesAdapter extends RecyclerView.Adapter<PocketMoviesAdapter.MovieViewHolder>{

    class MovieViewHolder extends RecyclerView.ViewHolder {
        private MovieViewHolder(View itemView) {
            super(itemView);
        }
    }
    private List<Movie> movies;
    @Override
    public MovieViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // get a layoutInflater from the context attached
        //to the parent view
        LayoutInflater layoutInflater =
                LayoutInflater.from(parent.getContext());

        // inflate the layout item_planet in a view
        View movieView =
                layoutInflater.inflate(R.layout.item_pocket_movie,parent,false);

        // create a new ViewHolder with the view planetView
        return new MovieViewHolder(movieView);
    }
    @Override
    public  void onBindViewHolder(MovieViewHolder holder, int position){
        Movie movie = movies.get(position);

        // get the planet name TextView of the item
        ViewGroup itemViewGroup = (ViewGroup)holder.itemView;

        TextView titleTextView = itemViewGroup.findViewById(R.id.text_item_title);
        titleTextView.setText(movie.getTitle());

        TextView ratingTextView = itemViewGroup.findViewById(R.id.recent_item_rating);
        ratingTextView.setText(String.valueOf(movie.getRating()));

        if (!movie.getImagePath().isEmpty()) {
            ImageView thumbnailImageView = itemViewGroup.findViewById(R.id.image_item);
            Picasso.get().load(movie.getImagePath()).into(thumbnailImageView);
        }
    }
    @Override
    public int  getItemCount(){
        if(movies==null){
            return 20;
        }else{
            return movies.size();
        }
    }



    public void setMovieData(List<Movie> movies) {

        this.movies = movies;

        //notify the adapter that the data have changed
        this.notifyDataSetChanged();
    }
}
