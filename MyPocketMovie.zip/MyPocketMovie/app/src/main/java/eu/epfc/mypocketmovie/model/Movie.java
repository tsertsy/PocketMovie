package eu.epfc.mypocketmovie.model;

/**
 * Created by Olivier on 12/05/2018.
 */

public class Movie {
    private String title;
    private String overview;
    private double rating;
    private String imagepath;
    public void setRating(double rating){
        this.rating=rating;
    }
    public void setTitle(String title){
        this.title=title;
    }
    public void setOverview(String overview){
        this.overview=overview;
    }
    public void setImagePath(String imagepath){
        this.imagepath=imagepath;
    }
    public String getTitle(){
        return this.title;
    }
    public double getRating(){
        return this.rating;
    }
    public String getOverview(){
        return this.overview;
    }
    public String getImagePath(){
        return this.imagepath;
    }
    public Movie(String title,String overview, double rating, String imagepath){
        this.title=title;
        this.overview=overview;
        this.rating=rating;
        this.imagepath=imagepath;
    }
}
